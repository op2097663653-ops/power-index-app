package com.powerindex.app;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private View splash;
    private boolean splashDone = false;
    private static final String START_URL = "https://op2097663653-ops.github.io/power-index-app/?v=app5";
    private static final int BG = 0xFFF6F6FB;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        View decor = getWindow().getDecorView();
        int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        decor.setSystemUiVisibility(flags);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        webView = new WebView(this);
        webView.setBackgroundColor(BG);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildSplash(), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        ViewCompat.setOnApplyWindowInsetsListener(webView, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideSplash(320);
            }
        });

        // 兜底：最多 8 秒也要收起启动页
        new Handler(Looper.getMainLooper()).postDelayed(() -> hideSplash(0), 8000);

        if (savedInstanceState == null) webView.loadUrl(START_URL);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private View buildSplash() {
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(110), dp(110));
        lp.gravity = Gravity.CENTER;
        lp.bottomMargin = dp(54);
        box.addView(logo, lp);

        TextView title = new TextView(this);
        title.setText("战力图鉴");
        title.setTextSize(20);
        title.setTextColor(0xFF1F2937);
        title.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tp.gravity = Gravity.CENTER;
        tp.topMargin = dp(96);
        box.addView(title, tp);

        TextView sub = new TextView(this);
        sub.setText("跨界战力对照");
        sub.setTextSize(12);
        sub.setTextColor(0xFF9CA3AF);
        sub.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        sp.gravity = Gravity.CENTER;
        sp.topMargin = dp(128);
        box.addView(sub, sp);

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(22), dp(22));
        bp.gravity = Gravity.CENTER;
        bp.topMargin = dp(176);
        box.addView(bar, bp);

        // 入場动画
        logo.setAlpha(0f);
        logo.setScaleX(0.82f);
        logo.setScaleY(0.82f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(520).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.setAlpha(0f);
        title.animate().alpha(1f).setStartDelay(180).setDuration(420).start();
        sub.setAlpha(0f);
        sub.animate().alpha(1f).setStartDelay(320).setDuration(420).start();

        splash = box;
        return box;
    }

    private void hideSplash(int extraDelay) {
        if (splashDone || splash == null) return;
        splashDone = true;
        splash.postDelayed(() -> splash.animate().alpha(0f).setDuration(300)
                .withEndAction(() -> {
                    if (splash.getParent() != null) {
                        ((android.view.ViewGroup) splash.getParent()).removeView(splash);
                    }
                }).start(), extraDelay);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (webView != null) webView.restoreState(savedInstanceState);
    }
}
