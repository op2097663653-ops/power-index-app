package com.powerindex.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private View splash;
    private boolean splashDone = false;
    private boolean triedFallback = false;
    private int insetTop = 0;
    private int insetBottom = 0;

    private static final String HOST_PRIMARY = "https://op2097663653-ops.github.io/power-index-app/";
    private static final String HOST_FALLBACK = "https://power-index-cn.netlify.app/";
    private static final String SHARE_TITLE = "战力图鉴 · 跨界角色战力对比";
    private static final int BG = 0xFFF6F6FB;

    private String urlWithStamp(String base) {
        return base + "?v=" + System.currentTimeMillis();
    }

    public class Bridge {
        @JavascriptInterface
        public void share(final String url) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_SUBJECT, SHARE_TITLE);
                send.putExtra(Intent.EXTRA_TEXT, SHARE_TITLE + "\n" + url);
                startActivity(Intent.createChooser(send, "分享到"));
            });
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 全屏绘制，系统栏留白交给网页（--inset-top / --inset-bottom）
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(true);
        controller.setAppearanceLightNavigationBars(true);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        webView = new WebView(this);
        webView.setBackgroundColor(BG);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        root.addView(buildSplash(), new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            insetTop = bars.top;
            insetBottom = bars.bottom;
            pushInsets();
            return insets;
        });
        ViewCompat.requestApplyInsets(root);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushInsets();
                hideSplash(220);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) handleLoadFail();
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                handleLoadFail();
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                runOnUiThread(() -> recreate());
                return true;
            }
        });

        if (savedInstanceState == null) webView.loadUrl(urlWithStamp(HOST_PRIMARY));
    }

    private void pushInsets() {
        if (webView == null) return;
        final String js = "window.__applyInsets&&window.__applyInsets(" + insetTop + "," + insetBottom + ")";
        webView.post(() -> {
            try { webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
        });
    }

    private void handleLoadFail() {
        runOnUiThread(() -> {
            if (!triedFallback) {
                triedFallback = true;
                webView.loadUrl(urlWithStamp(HOST_FALLBACK));
                return;
            }
            showErrorView();
        });
    }

    private void showErrorView() {
        hideSplash(0);
        FrameLayout root = (FrameLayout) webView.getParent();
        if (root == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(BG);
        box.setPadding(dp(28), dp(28) + insetTop, dp(28), dp(28) + insetBottom);

        TextView title = new TextView(this);
        title.setText("加载失败");
        title.setTextSize(20);
        title.setTextColor(0xFF1F2937);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView desc = new TextView(this);
        desc.setText("网络连接不上，请检查网络后重试");
        desc.setTextSize(13);
        desc.setTextColor(0xFF9CA3AF);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, dp(10), 0, dp(20));
        box.addView(desc);

        Button retry = new Button(this);
        retry.setText("重新加载");
        retry.setAllCaps(false);
        retry.setOnClickListener((v) -> {
            root.removeView(box);
            triedFallback = false;
            splashDone = false;
            webView.loadUrl(urlWithStamp(HOST_PRIMARY));
        });
        box.addView(retry);

        root.addView(box, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private View buildSplash() {
        FrameLayout box = new FrameLayout(this);
        box.setBackgroundColor(BG);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(110), dp(110));
        lp.gravity = Gravity.CENTER;
        lp.bottomMargin = dp(54);
        box.addView(logo, lp);

        TextView title = new TextView(this);
        title.setText("战力图鉴");
        title.setTextSize(20);
        title.setTextColor(0xFF1F2937);
        title.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        tp.gravity = Gravity.CENTER;
        tp.topMargin = dp(96);
        box.addView(title, tp);

        TextView sub = new TextView(this);
        sub.setText("跨界战力对照");
        sub.setTextSize(12);
        sub.setTextColor(0xFF9CA3AF);
        sub.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        sp.gravity = Gravity.CENTER;
        sp.topMargin = dp(128);
        box.addView(sub, sp);

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleSmall);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(22), dp(22));
        bp.gravity = Gravity.CENTER;
        bp.topMargin = dp(176);
        box.addView(bar, bp);

        logo.setAlpha(0f);
        logo.setScaleX(0.82f);
        logo.setScaleY(0.82f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(520).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.setAlpha(0f);
        title.animate().alpha(1f).setStartDelay(180).setDuration(420).start();
        sub.setAlpha(0f);
        sub.animate().alpha(1f).setStartDelay(320).setDuration(420).start();

        splash = box;
        return box;
    }

    private void hideSplash(int extraDelay) {
        if (splashDone || splash == null) return;
        splashDone = true;
        splash.postDelayed(() -> splash.animate().alpha(0f).setDuration(260)
                .withEndAction(() -> {
                    if (splash.getParent() != null) {
                        ((android.view.ViewGroup) splash.getParent()).removeView(splash);
                    }
                }).start(), extraDelay);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidBridge");
            webView.destroy();
        }
        super.onDestroy();
    }
}
